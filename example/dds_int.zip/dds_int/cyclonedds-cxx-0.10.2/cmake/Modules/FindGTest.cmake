# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

#[=======================================================================[.rst:
FindGTest
---------

Locate the Google C++ Testing Framework.

Imported targets
^^^^^^^^^^^^^^^^

This module defines the following :prop_tgt:`IMPORTED` targets:

``GTest::GTest``
  The Google Test ``gtest`` library, if found; adds Thread::Thread
  automatically
``GTest::Main``
  The Google Test ``gtest_main`` library, if found
``GTest::GMock``
  The Google Mock ``gmock`` library, if found; adds GTest::GTest
  automatically
``GTest::GMockMain``
  The Google Mock ``gmock_main`` library, if found


Result variables
^^^^^^^^^^^^^^^^

This module will set the following variables in your project:

``GTEST_FOUND``
  Found the Google Testing framework
``GTEST_INCLUDE_DIRS``
  the directory containing the Google Test headers
``GTEST_GMOCK_INCLUDE_DIRS``
  the directory containing the Google Mock headers

The library variables below are set as normal variables.  These
contain debug/optimized keywords when a debugging library is found.

``GTEST_LIBRARIES``
  The Google Test ``gtest`` library; note it also requires linking
  with an appropriate thread library
``GTEST_MAIN_LIBRARIES``
  The Google Test ``gtest_main`` library
``GTEST_BOTH_LIBRARIES``
  Both ``gtest`` and ``gtest_main``
``GTEST_GMOCK_LIBRARIES``
  The Google Mock ``gmock`` library
``GTEST_GMOCK_MAIN_LIBRARIES``
  The Google Mock ``gmock_main`` library
``GTEST_GMOCK_BOTH_LIBRARIES``
  Both ``gmock`` and ``gmock_main``

Cache variables
^^^^^^^^^^^^^^^

The following cache variables may also be set:

``GTEST_ROOT``
  The root directory of the Google Test installation (may also be
  set as an environment variable)
``GTEST_MSVC_SEARCH``
  If compiling with MSVC, this variable can be set to ``MT`` or
  ``MD`` (the default) to enable searching a GTest build tree


Example usage
^^^^^^^^^^^^^

::

    enable_testing()
    find_package(GTest REQUIRED)

    add_executable(foo foo.cc)
    target_link_libraries(foo GTest::GTest GTest::Main)

    add_test(AllTestsInFoo foo)


Deeper integration with CTest
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

See :module:`GoogleTest` for information on the :command:`gtest_add_tests`
and :command:`gtest_discover_tests` commands.
#]=======================================================================]

include(GoogleTest)

function(__gtest_append_debugs _endvar _library)
    if(${_library} AND ${_library}_DEBUG)
        set(_output optimized ${${_library}} debug ${${_library}_DEBUG})
    else()
        set(_output ${${_library}})
    endif()
    set(${_endvar} ${_output} PARENT_SCOPE)
endfunction()

function(__gtest_find_library _name)
    find_library(${_name}
        NAMES ${ARGN}
        HINTS
            ENV GTEST_ROOT
            ${GTEST_ROOT}
        PATH_SUFFIXES ${_gtest_libpath_suffixes}
    )
    mark_as_advanced(${_name})
endfunction()

function(__gtest_find_library_configuration _name _lib _cfg_suffix)
    set(_libs ${_lib})
    if(MSVC AND GTEST_MSVC_SEARCH STREQUAL "MD")
        # The provided /MD project files for Google Test add -md suffixes to the
        # library names.
        list(INSERT _libs 0 ${_lib}-md)
    endif()
    list(TRANSFORM _libs APPEND "${_cfg_suffix}")

    __gtest_find_library(${_name} ${_libs})
endfunction()

include(SelectLibraryConfigurations)
function(__gtest_find_and_select_library_configurations _basename _lib)
    __gtest_find_library_configuration(${_basename}_LIBRARY_RELEASE ${_lib} "")
    __gtest_find_library_configuration(${_basename}_LIBRARY_DEBUG   ${_lib} "d")

    select_library_configurations(${_basename})
    set(${_basename}_LIBRARY ${${_basename}_LIBRARY} PARENT_SCOPE)
endfunction()

macro(__gtest_determine_windows_library_type _var)
    if(EXISTS "${${_var}}")
        file(TO_NATIVE_PATH "${${_var}}" _lib_path)
        get_filename_component(_name "${${_var}}" NAME_WE)
        file(STRINGS "${${_var}}" _match REGEX "${_name}\\.dll" LIMIT_COUNT 1)
        if(NOT _match STREQUAL "")
            set(${_var}_TYPE SHARED PARENT_SCOPE)
        else()
            set(${_var}_TYPE UNKNOWN PARENT_SCOPE)
        endif()
        return()
    endif()
endmacro()

function(__gtest_determine_library_type _var)
    if(WIN32)
        # For now, at least, only Windows really needs to know the library type
        __gtest_determine_windows_library_type(${_var})
        __gtest_determine_windows_library_type(${_var}_RELEASE)
        __gtest_determine_windows_library_type(${_var}_DEBUG)
    endif()
    # If we get here, no determination was made from the above checks
    set(${_var}_TYPE UNKNOWN PARENT_SCOPE)
endfunction()

function(__gtest_import_library _target _var _config)
    if(_config)
        set(_config_suffix "_${_config}")
    else()
        set(_config_suffix "")
    endif()

    set(_lib "${${_var}${_config_suffix}}")
    if(EXISTS "${_lib}")
        if(_config)
            set_property(TARGET ${_target} APPEND PROPERTY
                IMPORTED_CONFIGURATIONS ${_config})
        endif()
        set_target_properties(${_target} PROPERTIES
            IMPORTED_LINK_INTERFACE_LANGUAGES${_config_suffix} "CXX")
        if(WIN32 AND ${_var}_TYPE STREQUAL SHARED)
            set_target_properties(${_target} PROPERTIES
                IMPORTED_IMPLIB${_config_suffix} "${_lib}")
            # Locate the dynamic link library
            get_filename_component(_basedir "${_lib}" PATH)
            get_filename_component(_basename "${_lib}" NAME_WE)
            get_filename_component(_prefix "${_basedir}" PATH)
            find_program(_dll "${_basename}.dll" HINTS ${_prefix} PATH_SUFFIXES bin NO_DEFAULT_PATH)
            if (EXISTS "${_dll}")
                set_target_properties(${_target} PROPERTIES
                    IMPORTED_LOCATION${_config_suffix} "${_dll}")
            endif()
        else()
            set_target_properties(${_target} PROPERTIES
                IMPORTED_LOCATION${_config_suffix} "${_lib}")
        endif()
    endif()
endfunction()

#

if(NOT DEFINED GTEST_MSVC_SEARCH)
    set(GTEST_MSVC_SEARCH MD)
endif()

set(_gtest_libpath_suffixes lib)
if(MSVC)
    if(GTEST_MSVC_SEARCH STREQUAL "MD")
        list(APPEND _gtest_libpath_suffixes
            msvc/gtest-md/Debug
            msvc/gtest-md/Release
            msvc/x64/Debug
            msvc/x64/Release
            msvc/2010/gtest-md/Win32-Debug
            msvc/2010/gtest-md/Win32-Release
            msvc/2010/gtest-md/x64-Debug
            msvc/2010/gtest-md/x64-Release
            msvc/gmock-md/Debug
            msvc/gmock-md/Release
            )
    elseif(GTEST_MSVC_SEARCH STREQUAL "MT")
        list(APPEND _gtest_libpath_suffixes
            msvc/gtest/Debug
            msvc/gtest/Release
            msvc/x64/Debug
            msvc/x64/Release
            msvc/2010/gtest/Win32-Debug
            msvc/2010/gtest/Win32-Release
            msvc/2010/gtest/x64-Debug
            msvc/2010/gtest/x64-Release
            msvc/gmock/Debug
            msvc/gmock/Release
            )
    endif()
endif()


find_path(GTEST_INCLUDE_DIR gtest/gtest.h
    HINTS
        $ENV{GTEST_ROOT}/include
        ${GTEST_ROOT}/include
)
mark_as_advanced(GTEST_INCLUDE_DIR)

find_path(GTEST_GMOCK_INCLUDE_DIR gmock/gmock.h
    HINTS
        $ENV{GTEST_ROOT}/include
        ${GTEST_ROOT}/include
)
mark_as_advanced(GTEST_GMOCK_INCLUDE_DIR)

# Allow GTEST_LIBRARY and GTEST_MAIN_LIBRARY to be set manually, as the
# locations of the gtest and gtest_main libraries, respectively.
if(NOT GTEST_LIBRARY)
    __gtest_find_and_select_library_configurations(GTEST gtest)
endif()
if(NOT GTEST_MAIN_LIBRARY)
    __gtest_find_and_select_library_configurations(GTEST_MAIN gtest_main)
endif()
if(NOT GTEST_GMOCK_LIBRARY)
    __gtest_find_and_select_library_configurations(GTEST_GMOCK gmock)
endif()
if(NOT GTEST_GMOCK_MAIN_LIBRARY)
    __gtest_find_and_select_library_configurations(GTEST_GMOCK_MAIN gmock_main)
endif()

include(FindPackageHandleStandardArgs)
FIND_PACKAGE_HANDLE_STANDARD_ARGS(GTest DEFAULT_MSG GTEST_LIBRARY GTEST_INCLUDE_DIR GTEST_MAIN_LIBRARY
                                                    GTEST_GMOCK_LIBRARY GTEST_GMOCK_INCLUDE_DIR GTEST_GMOCK_MAIN_LIBRARY)

if(GTEST_FOUND)
    set(GTEST_INCLUDE_DIRS ${GTEST_INCLUDE_DIR})
    __gtest_append_debugs(GTEST_LIBRARIES      GTEST_LIBRARY)
    __gtest_append_debugs(GTEST_MAIN_LIBRARIES GTEST_MAIN_LIBRARY)
    set(GTEST_BOTH_LIBRARIES ${GTEST_LIBRARIES} ${GTEST_MAIN_LIBRARIES})
    set(GTEST_GMOCK_INCLUDE_DIRS ${GTEST_GMOCK_INCLUDE_DIR})
    __gtest_append_debugs(GTEST_GMOCK_LIBRARIES      GTEST_GMOCK_LIBRARY)
    __gtest_append_debugs(GTEST_GMOCK_MAIN_LIBRARIES GTEST_GMOCK_MAIN_LIBRARY)
    set(GTEST_GMOCK_BOTH_LIBRARIES ${GTEST_GMOCK_LIBRARIES} ${GTEST_GMOCK_MAIN_LIBRARIES})

    find_package(Threads QUIET)

    if(NOT TARGET GTest::GTest)
        __gtest_determine_library_type(GTEST_LIBRARY)
        add_library(GTest::GTest ${GTEST_LIBRARY_TYPE} IMPORTED)
        if(TARGET Threads::Threads)
            set_target_properties(GTest::GTest PROPERTIES
                INTERFACE_LINK_LIBRARIES Threads::Threads)
        endif()
        if(GTEST_LIBRARY_TYPE STREQUAL "SHARED")
            set_target_properties(GTest::GTest PROPERTIES
                INTERFACE_COMPILE_DEFINITIONS "GTEST_LINKED_AS_SHARED_LIBRARY=1")
        endif()
        if(GTEST_INCLUDE_DIRS)
            set_target_properties(GTest::GTest PROPERTIES
                INTERFACE_INCLUDE_DIRECTORIES "${GTEST_INCLUDE_DIRS}")
        endif()
        __gtest_import_library(GTest::GTest GTEST_LIBRARY "")
        __gtest_import_library(GTest::GTest GTEST_LIBRARY "RELEASE")
        __gtest_import_library(GTest::GTest GTEST_LIBRARY "DEBUG")
    endif()
    if(NOT TARGET GTest::Main)
        __gtest_determine_library_type(GTEST_MAIN_LIBRARY)
        add_library(GTest::Main ${GTEST_MAIN_LIBRARY_TYPE} IMPORTED)
        set_target_properties(GTest::Main PROPERTIES
            INTERFACE_LINK_LIBRARIES "GTest::GTest")
        __gtest_import_library(GTest::Main GTEST_MAIN_LIBRARY "")
        __gtest_import_library(GTest::Main GTEST_MAIN_LIBRARY "RELEASE")
        __gtest_import_library(GTest::Main GTEST_MAIN_LIBRARY "DEBUG")
    endif()

    if(NOT TARGET GTest::GMock)
        __gtest_determine_library_type(GTEST_GMOCK_LIBRARY)
        add_library(GTest::GMock ${GTEST_GMOCK_LIBRARY_TYPE} IMPORTED)
        if(NOT GTEST_GMOCK_LIBRARY_TYPE STREQUAL "SHARED")
            set_target_properties(GTest::GMock PROPERTIES
                INTERFACE_LINK_LIBRARIES GTest::GTest)
        endif()
        if(GTEST_GMOCK_INCLUDE_DIRS)
            set_target_properties(GTest::GMock PROPERTIES
                INTERFACE_INCLUDE_DIRECTORIES "${GTEST_GMOCK_INCLUDE_DIRS}")
        endif()
        __gtest_import_library(GTest::GMock GTEST_GMOCK_LIBRARY "")
        __gtest_import_library(GTest::GMock GTEST_GMOCK_LIBRARY "RELEASE")
        __gtest_import_library(GTest::GMock GTEST_GMOCK_LIBRARY "DEBUG")
    endif()
    if(NOT TARGET GTest::GMockMain)
        __gtest_determine_library_type(GTEST_GMOCK_MAIN_LIBRARY)
        add_library(GTest::GMockMain ${GTEST_GMOCK_MAIN_LIBRARY_TYPE} IMPORTED)
        set_target_properties(GTest::GMockMain PROPERTIES
            INTERFACE_LINK_LIBRARIES "GTest::GMock")
        __gtest_import_library(GTest::GMockMain GTEST_GMOCK_MAIN_LIBRARY "")
        __gtest_import_library(GTest::GMockMain GTEST_GMOCK_MAIN_LIBRARY "RELEASE")
        __gtest_import_library(GTest::GMockMain GTEST_GMOCK_MAIN_LIBRARY "DEBUG")
    endif()

    # Add targets mapping the same library names as defined in
    # GTest's CMake package config.
    if(NOT TARGET GTest::gtest)
        add_library(GTest::gtest INTERFACE IMPORTED)
        target_link_libraries(GTest::gtest INTERFACE GTest::GTest)
    endif()
    if(NOT TARGET GTest::gtest_main)
        add_library(GTest::gtest_main INTERFACE IMPORTED)
        target_link_libraries(GTest::gtest_main INTERFACE GTest::Main)
    endif()
    if(NOT TARGET GTest::gmock)
        add_library(GTest::gmock INTERFACE IMPORTED)
        target_link_libraries(GTest::gmock INTERFACE GTest::GMock)
    endif()
    if(NOT TARGET GTest::gmock_main)
        add_library(GTest::gmock_main INTERFACE IMPORTED)
        target_link_libraries(GTest::gmock_main INTERFACE GTest::GMockMain)
    endif()
endif()
